# Lumiora Skincare Website

## Project
WEDE5020 POE Part 1 — Lumiora Skincare (Pty) Ltd.

This website is based on the supplied Lumiora Theory / Website Project Proposal.

## Pages
- `index.html` — Home page with hero section, introduction and brand promise.
- `about.html` — Company background, mission/vision context, values and target audience.
- `products.html` — Product catalogue for cleanser, moisturizer, face serum, soap, cream and mask, with product search.
- `enquiry.html` — Product, partnership, bulk-order and support enquiry form.
- `contact.html` — Contact details and contact form.

## Supporting files
- `css/style.css` — External responsive CSS stylesheet.
- `js/script.js` — Navigation, product search and demonstration form handling.
- `assets/lumiora-brand.svg` — Local brand artwork.
- `sitemap.xml` — Basic sitemap.
- `robots.txt` — Basic crawler instructions.

## Technologies
HTML5, CSS3, JavaScript, Google Fonts, GitHub and Visual Studio Code are aligned with the proposal.

## Brand colours
- Primary: `#D89CA4` — Soft Rose Pink
- Secondary: `#FFF8F4` — Cream White
- Accent: `#B76E79` — Rose Gold
- Dark text: `#333333`
- Buttons: `#E8B4B8`

## Running the website
1. Extract the ZIP.
2. Open `index.html` in a browser, or use Visual Studio Code with Live Server.
3. Navigate between the pages using the menu.
4. The forms are demonstration forms. They do not send data to a live server until a backend/email service is connected.

## Notes
The proposal states that the website should include navigation, product cards, contact forms, image gallery, social-media integration, mobile-friendly layout and search functionality. The implementation includes these core front-end requirements; social links and form submission are placeholders ready for real accounts/backend integration.

The proposal also specifies `www.Lumioratheory.co.za`, shared hosting, approximately 15 GB storage and SSL as technical requirements. A real deployment would require registering/configuring the domain and hosting separately.
